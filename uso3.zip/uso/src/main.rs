use std::process::Command;

fn main() {
    let output = Command::new("cmd.exe")
    .arg("/c")
    .arg("dir")
    .output()
    .expect("Error a la hora de ejecutar el comando");

    println!("{}", String::from_utf8_lossy(&output.stdout));
}

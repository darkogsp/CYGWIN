use std::path::Path;
use std::process::Command;
use std::fs;
use glob;

fn main() {
    let output = Command::new("cmd.exe")
        .arg("/c")
        .arg(r"C:\Users\Usuario\Desktop\PROVEEDOR\lib\pdftohtml.exe C:\Users\Usuario\Desktop\PROVEEDOR\Factura_proveedor_ejemplo.pdf")
        .output()
        .expect("Error a la hora de ejecutar el comando");

    println!("{}", String::from_utf8_lossy(&output.stdout));

    let ruta = Path::new(r"C:\Users\Usuario\Desktop\PROVEEDOR");

    for entry in fs::read_dir(ruta).unwrap() {
        let entry = entry.unwrap();
        let path = entry.path();

        if path.is_file() && path.extension().unwrap() == "png" {
            fs::remove_file(&path).unwrap();
            println!("Archivo eliminado: {}", path.display());
        }
    }

    let patron = "*_ind.html";

    for entry in glob::glob(ruta.join(patron).to_str().unwrap()).unwrap() {
        let path = entry.unwrap();

        fs::remove_file(&path).unwrap();
        println!("Archivo _ind.html eliminado: {}", path.display());
    }

    let pdf_nombre = "Factura_proveedor_ejemplo.pdf";
    let html_nombre = pdf_nombre.replace(".pdf", "s.html");

    let html_path = ruta.join(&html_nombre);

    if html_path.exists() {
        let contenido = fs::read_to_string(&html_path).unwrap();
        println!("{}", contenido);
    } else {
        println!("Archivo {} no encontrado", html_nombre);
    }
}

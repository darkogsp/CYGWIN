use std::path::Path;
use std::process::Command;
use std::fs;

fn main() {
    let output = Command::new("cmd.exe")
    .arg("/c")
    .arg(r"C:\Users\Usuario\Desktop\PROVEEDOR\lib\pdftohtml.exe C:\Users\Usuario\Desktop\PROVEEDOR\Factura_proveedor_ejemplo.pdf")
    .output()
    .expect("Error a la hora de ejecutar el comando");

    println!("{}", String::from_utf8_lossy(&output.stdout));

    let ruta = Path::new(r"C:\Users\Usuario\Desktop\PROVEEDOR");
    
    for entry in fs::read_dir(ruta).unwrap() {
        let entry = entry.unwrap();
        let path = entry.path();

        if path.is_file() && path.extension().unwrap() == "png" {
            fs::remove_file(&path).unwrap();
            println!("Archivo eliminado: {}", path.display());
        }
    }

    fs::remove_file(r"C:\Users\Usuario\Desktop\PROVEEDOR\*.png").expect("Error a la hora de eliminar las imágenes");
}

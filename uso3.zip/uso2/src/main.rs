use std::process::Command;

fn main() {
    let output = Command::new("cmd.exe")
    .arg("/c")
    .arg(r"C:\Users\Usuario\Desktop\PROVEEDOR\lib\pdftohtml.exe C:\Users\Usuario\Desktop\PROVEEDOR\Factura_proveedor_ejemplo.pdf")
    .output()
    .expect("Error a la hora de ejecutar el comando");

    println!("{}", String::from_utf8_lossy(&output.stdout));
}
